South East Asia Provinces Shape File (1966) v1.0
6/21/2011
Rex W. Douglass
rexdouglass@gmail.com

Description: Country political boundaries for South Vietnam, North Vietnam, Cambodia, and Laos. Partial country boundaries for Thailand, Berma, and China.Based on "Indochina Administrative Divisions September 1966"

Copyright Rex W. Douglass 2011
The file is freely available for academic research under the conditions that 1) it not be redistributed without express permission, 2) it not be redistributed without this readme file, and 3) any research using this file in whole or in part provides citation to the work, 

Rex W. Douglass, The Digital Vietnam War: Big Data from over a Decade of Combat in Southeast Asia, v1.0, June 21, 2011 




